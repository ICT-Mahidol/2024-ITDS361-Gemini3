## **Class Diagram**
![image]()

============================================================================================

## **Usecase Description Create an observing program**
![image](https://github.com/user-attachments/assets/8a06d31c-8330-43a8-9637-c76d1bb69f42)
![image](https://github.com/user-attachments/assets/26390120-b256-4e9c-8fbb-6025409112a6)

## **Activity Diagram Create an observing program**
![image](https://github.com/user-attachments/assets/c3e23282-0a37-4a8d-b9e6-f96ba8686808)

## **Sequence Diagrams Create an observing program**  
![image](https://github.com/user-attachments/assets/41c749d9-54c7-4d60-a57f-e8a35b699d63)

============================================================================================

## **Usecase Description Access collected astronomical data**
![image](https://github.com/user-attachments/assets/1d86f1f7-70e0-44ad-bf20-5302ad8dd0c6)

## **Activity Diagram Access collected astronomical data**
![image](https://github.com/user-attachments/assets/cc4208da-4838-416c-8b35-35e73e000b0d)

## **Sequence Diagrams Access collected astronomical data**  
![image]()

============================================================================================

## **Usecase Description Execute approved science plan**
![image](https://github.com/user-attachments/assets/13c50001-7fb6-4c58-92eb-ed308f9a8ed9)

## **Activity Diagram Execute approved science plan**
![image](https://github.com/user-attachments/assets/197e6c71-5595-4e6c-a4ca-8f1fb2b79f25)

## **Sequence Diagrams Execute approved science plan**  
![image](https://github.com/user-attachments/assets/1984b332-63fd-4680-8528-941e92405e41)


============================================================================================



